$(".btn").click(function () {
	alert("Funcionou!!!");
});
